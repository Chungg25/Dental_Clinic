const appoinmentController = require('./appointment.controller');
const chatbotController = require('./chatbot.controller');
const retrieveDataController = require('./retrieve-data.controller');

module.exports = {
    appoinmentController,
    chatbotController,
    retrieveDataController
}